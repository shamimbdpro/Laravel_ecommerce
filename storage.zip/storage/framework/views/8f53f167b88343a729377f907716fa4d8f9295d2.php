<?php $__env->startSection('contents'); ?>
			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a>
					<i class="icon-angle-right"></i> 
				</li>
				<li>
					<i class="icon-edit"></i>
					<a href="#">Add Slider</a>
				</li>
			</ul>
			
			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon edit"></i><span class="break"></span>Add Product</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>

					<div class="box-content">
						 <?php if(Session('slider')): ?>
						    <p class="sucmsg">Product Inserted Suceesfully</p>
						<?php endif; ?>
						<form class="form-horizontal" action="<?php echo e(route('insertslider')); ?>" method="post" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
						  <fieldset>
					
                             <div class="control-group">
							  <label class="control-label" for="slidertitle">Slider Title</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" id="product_color" name="slidertitle" value="<?php echo e(old('slidertitle')); ?>">
								     <?php if($errors->has('slidertitle')): ?>
                                     	<p class="help-block"> <?php echo e($errors->first('slidertitle')); ?></p>
                                <?php endif; ?>
							  </div>
							</div>	

							<div class="control-group">
							  <label class="control-label" for="Subtitle">Slider Subtitle</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" id="product_color" name="Subtitle" value="<?php echo e(old('Subtitle')); ?>">
							  </div>
							</div>	

							<div class="control-group hidden-phone">
							  <label class="control-label" for="slider_p">Slider Description</label>
							  <div class="controls">
								<textarea class="cleditor" id="slider_p" rows="3" name="slider_p"><?php echo e(old('slider_p')); ?></textarea>
							  </div>
							</div>

	                    


	                        <div class="control-group">
							  <label class="control-label" for="slider_img">Slider Image</label>
							  <div class="controls">
								<input type="file" class="span6 typeahead" id="slider_img" name="slider_img" value="<?php echo e(old('slider_img')); ?>">
						        <?php if($errors->has('slider_img')): ?>
                                     	<p class="help-block"> <?php echo e($errors->first('slider_img')); ?></p>
                                <?php endif; ?>
							  </div>
							</div>

							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">Add Slider</button>
							</div>

						  </fieldset>
						</form>   

					</div>
				</div><!--/span-->

			</div><!--/row-->

		
			
	
    

	</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>