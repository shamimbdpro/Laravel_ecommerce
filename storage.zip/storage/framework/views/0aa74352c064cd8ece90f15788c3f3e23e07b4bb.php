<?php $__env->startSection('contents'); ?>

<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb" style="margin-bottom:40px">
				  <li><a href="#">Home</a></li>
				  <li class="active">Shopping Cart</li>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="image">Name</td>
							<td class="price">Price</td>
							<td class="description"></td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
					<?php
                    $contents=Cart::content();
                     ?>
                      <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="cart_product">
								<a href=""><img height="60" src="<?php echo e(asset('contents/uploads/product')); ?>/<?php echo e($content1->options->p_img); ?>" alt=""></a>
							</td>
							<td class="cart_description">
								<h4><a href="<?php echo e(route('singleProduct',$content1->id)); ?>"><?php echo e($content1->name); ?></a></h4>
								<p>Web ID: 1089772</p>
							</td>
							<td class="cart_price">
								<p>$<?php echo e($content1->price); ?></p>
							</td>
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									<form action="<?php echo e(route('update_cart',$content1->rowId)); ?>" method="post">
										<?php echo csrf_field(); ?>
									<input style="width:80px" class="cart_quantity_input" type="number" name="qty" value="<?php echo e($content1->qty); ?>" autocomplete="off" size="2">
									<button type="submit" >update</button>
									</form>
								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price">$<?php echo e($content1->total); ?></p>
							</td>
							<td class="cart_delete">
								<a class="cart_quantity_delete" href="<?php echo e(route('delete_cart',$content1->rowId)); ?>"><i class="fa fa-times"></i></a>
							</td>
						</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</tbody>
				</table>
			</div>
		</div>
	</section> <!--/#cart_items-->

<form action="<?php echo e(route('Place_order')); ?>" method="post">
	<?php echo csrf_field(); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-6">
			<div class="selectPayment ">
				
			  	<input type="radio" name="emotion" 
			  id="sad" class="input-hidden" value="Bikash" required/>
			<label for="sad">
			  <img 
			    src="<?php echo e(asset('contents/frontend')); ?>/images/payment/bkash.jpg" 
			    alt="" />
			</label>

			<input 
			  type="radio" name="emotion"
			  id="happy" class="input-hidden" value="DBBL" required/>
			<label for="happy">
			  <img 
			     src="<?php echo e(asset('contents/frontend')); ?>/images/payment/1200px-DBBL.jpg" 
			    alt="" />
			</label>
			  

			  <input 
			  type="radio" name="emotion"
			  id="happy2" class="input-hidden" value="handcash" required/>
			<label for="happy2">
			  <img 
			     src="<?php echo e(asset('contents/frontend')); ?>/images/payment/handcash.jpg" 
			    alt="" />
			</label>
			  <input 
			  type="radio" name="emotion"
			  id="happy23" class="input-hidden" value="Paypal" required/>
			<label for="happy23">
			  <img 
			     src="<?php echo e(asset('contents/frontend')); ?>/images/payment/paypal.png" 
			    alt="" />
			</label>
			  </div>
			
		  </div>
    </div>
</div>

 <div class="checkoutbtn" style="text-align: center;">
		  <button type="submit" class="btn btn-default get">Place Order</button>
		</div>
</form>





  <style type="text/css"> 
 .input-hidden {
  position: absolute;
  left: -9999px;
}

input[type=radio]:checked + label>img {
  border: 1px solid #fff;
  box-shadow: 0 0 3px 3px #090;
 
}

/* Stuff after this is only to make things more pretty */
input[type=radio] + label>img {
  border: 1px dashed #444;
  width: 100px;
  height: 80px;
  transition: 500ms all;
  margin-right: 20px;
   cursor: pointer
}




</style>





















<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>