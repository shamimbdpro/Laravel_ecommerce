<?php $__env->startSection('contents'); ?>
	
	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Login to your account</h2>

						<form action="<?php echo e(route('customerLogin')); ?>" method="post" >
							<?php echo csrf_field(); ?>
							<input type="email" placeholder="Email" name="customerEmail"/>
							<?php if($errors->has('customerEmail')): ?>
                                     	<p style="color: #e11f1f;font-size:12px" class="help-block"> <?php echo e($errors->first('customerEmail')); ?></p>
                            <?php endif; ?>
							<input type="passowrd" placeholder="Enter Password" name="customerPass"/>
							<?php if($errors->has('customerPass')): ?>
                                     	<p style="color: #e11f1f;font-size:12px" class="help-block"> <?php echo e($errors->first('customerPass')); ?></p>
                            <?php endif; ?>
							<span>
								<input type="checkbox" class="checkbox"> 
								Keep me signed in
							</span>
							<button type="submit" class="btn btn-default">Login</button>
						</form>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>New User Signup!</h2>
						<form action="<?php echo e(route('customerRegister')); ?>" method="post">
							<?php echo csrf_field(); ?>
							<input type="text" placeholder="Name" name="customerName" value="<?php echo e(old('customerName')); ?>" />
							 <?php if($errors->has('customerName')): ?>
                                     	<p style="color: #e11f1f;font-size:12px" class="help-block"> <?php echo e($errors->first('customerName')); ?></p>
                                <?php endif; ?>
							<input type="email" placeholder="Email Address" name="customerEmail" value="<?php echo e(old('customerEmail')); ?>" />
							 <?php if($errors->has('customerEmail')): ?>
                                     	<p style="color: #e11f1f;font-size:12px" class="help-block"> <?php echo e($errors->first('customerEmail')); ?></p>
                                <?php endif; ?>
							<input type="password" placeholder="Password" name="customerPass" value="<?php echo e(old('customerPass')); ?>" />

							 <?php if($errors->has('customerPass')): ?>
                                     	<p style="color: #e11f1f;font-size:12px" class="help-block"> <?php echo e($errors->first('customerPass')); ?></p>
                                <?php endif; ?>
							<button type="submit" class="btn btn-default">Signup</button>
						</form>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>