<?php $__env->startSection('contents'); ?>
			
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Product</a></li>
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon user"></i><span class="break"></span>Members</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
				<?php if(session('order')): ?>
				    <div class="alert alert-success" style="font-weight: 900">
				        <?php echo e(session('order')); ?>

				    </div>
				<?php endif; ?>
				 
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Order Id</th>
								  <th>Cutomer name</th>
								  <th>Order Price</th>
								   <th>Pyment Method</th>
								  <th>Status</th>
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
						  	     <?php $x=0 ?>
						  	<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  	   <?php $x++; ?>
							<tr>
								<td><?php echo e($x); ?></td>
								<td class="center"><?php echo e($order->customerName->customerName); ?></td>
								<td class="center">$<?php echo e($order->order_total); ?></td>
								<td class="center product1">
								   <?php echo e($order->paymentName->payent_method); ?>

								</td>
								 <td class="center text-center">
								   <?php if($order->order_status==1): ?>
									<a style="width:70px" href="#" class="btn btn-small btn-success ">Active</a>
									<?php else: ?>
									<a style="width:70px" href="#" class="btn btn-small btn-inverse">panding</a>
									<?php endif; ?>
								</td>

								<td class="center">
									<a class="btn btn-primary" href="#">
										<i class="halflings-icon white edit"></i>  
									</a>
									<a class="btn btn-primary" href="<?php echo e(route('vieworder',$order->order_id)); ?>">
										<i class="halflings-icon white zoom-in"></i>  
									</a>
									<a class="btn btn-danger" href="<?php echo e(route('delete_order',$order->order_id)); ?>">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

			
	
	<div class="clearfix"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>