<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class manufacture extends Model
{
    //
}
