<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_payment extends Model
{
    //
}
