@extends('layouts.frontend')
@section('contents')

<div class="container"> 
	<div class="row"> 
		<div class="col-md-12"> 
            <div class="jumbotron text-xs-center">
				  <h1 class="display-3">Thank You!</h1>
				  <p class="lead"><strong>we are very happy to purchase product with us</strong> for further instructions on how to complete purchase product.</p>
				  <hr>
				  <p>
					Having trouble? <a href="">Contact us</a>
				  </p>
				  <p class="lead">
					<a class="btn btn-primary btn-sm" href="#" role="button">Donwload Purchase PDF</a>
				  </p>
				</div>
		</div>
	</div>
</div>


@endsection